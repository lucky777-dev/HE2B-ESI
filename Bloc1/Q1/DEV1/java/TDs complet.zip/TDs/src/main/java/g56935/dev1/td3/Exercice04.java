/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package g56935.dev1.td3;

/**
 *
 * @author g56935
 */
public class Exercice04 {
    public static void main(String[] args) {
        System.out.println("10 < 20 : "+(10<20));
        System.out.println("10 > 20 : "+(10>20));
        System.out.println("1 == 2 : "+(1==2));
        System.out.println("20.0/2 != 10.0 : "+(20.0/2!=10.0));
    }
}
