/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package g56935.dev1.td2;

/**
 *
 * @author g56935
 */
public class Exercice02 {
    public static void main(String[] args) {
        double a = 2.5;
        double b = 3.3;
        double c = 4.9;
        System.out.println("a = 2,5 | b = 3,3 | c = 4,9");
        System.out.println("");
        System.out.println("4 * a * c = 4 * "+a+" * "+c+" = "+(4*a*c));
        System.out.println("b*b - 4*a*c = "+b+"*"+b+" - 4*"+a+"*"+c+" = " + ((b*b)-(4*a*c)));
    }
}
